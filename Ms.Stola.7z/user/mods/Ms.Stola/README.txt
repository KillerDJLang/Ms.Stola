Nobody ever reads these anyway but uhhhh....yeah. Thanks for the download.
Just extract into your spt directory and it'll follow the pathing. If it doesn't for some odd reason just drop the SariaShop folder into your user/mods folder.
Enjoy!!